import '../styles/globals.css';

export default function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center text-center p-6">
      <div className="bg-white shadow-xl rounded-2xl p-10 max-w-lg">
        <h1 className="text-3xl font-bold mb-4">🍰 Bienvenido</h1>
        <p className="mb-6">Sitio sencillo para tu tienda de postres. Iremos agregando catálogo, promos y pedidos.</p>
        <a href="https://wa.me/" className="bg-green-500 text-white px-4 py-2 rounded-xl">Hacer pedido</a>
      </div>
    </div>
  );
}
